import tensorflow as tf
sess = tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(log_device_placement=True))

sess.list_devices()

from tensorflow import keras
model = keras.models.load_model('./model.h5')

def load_image(img_path, show=False):

    img = image.load_img(img_path, target_size=(150, 150))
    img_tensor = image.img_to_array(img)                    # (height, width, channels)
    img_tensor = np.expand_dims(img_tensor, axis=0)         # (1, height, width, channels), add a dimension because the model expects this shape: (batch_size, height, width, channels)
    img_tensor /= 255.                                      # imshow expects values in the range [0, 1]

    if show:
        plt.imshow(img_tensor[0])                           
        plt.axis('off')
        plt.show()

    return img_tensor
  

from keras.preprocessing import image
import numpy as np
import time
img_path = '../autolevel-small/test/false/camera-36_2020-10-25_21-45_to_2020-10-25_21-57.mp40661.jpg'
#expect [100, 0]
new_image = load_image(img_path)

pred = model.predict(new_image)

if (pred[0][0] > pred[0][1]):
  print("Eval: False")
else:
  print("Eval: True")

from datetime import datetime

while True:
    t1=datetime.now()
    pred = model.predict(new_image)
    t2=datetime.now()

    print(t2-t1)


    if (pred[0][0] > pred[0][1]):
      print("Eval: False")
    else:
      print("Eval: True")
    time.sleep(5)



